# Mi panel personal

> Esta carpeta se excluye de Git. Cada integrante mantiene aquí sus notas privadas.

## Mis prioridades
- [ ] 

## Tareas asignadas
- [ ] 

## Dudas para el equipo
- 

## Bloqueos
- 

## Registro
| Fecha | Avance | Próximo paso | Bloqueo |
|---|---|---|---|
| | | | |
