# Bitácora personal

No incluir contraseñas, datos sensibles ni información personal de postulantes.

### YYYY-MM-DD
- Objetivo:
- Avance:
- Aprendizaje:
- Dificultad:
- Próximo paso:
